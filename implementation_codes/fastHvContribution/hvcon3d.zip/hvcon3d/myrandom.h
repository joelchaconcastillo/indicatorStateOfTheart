#ifndef _MYRANDOM_H 
#define _MYRANDOM_H 1
double random_uniform_0_1(void);
double random_normal(void);
#endif
