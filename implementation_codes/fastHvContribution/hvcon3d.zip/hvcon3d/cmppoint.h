#include "hycon3d.h"
#include "avl.h"

#ifndef _CMPPOINT_H
#define _CMPPOINT_H
int cmppoint(void* a,void* b);
#endif
