#include "avl.h"
#include "hycon3d.h"

#ifndef _MYLISTPOINTTREE_H
#define _MYLISTPOINTTREE_H 1

void listPointTree(point_avl* a,int m);

#endif
