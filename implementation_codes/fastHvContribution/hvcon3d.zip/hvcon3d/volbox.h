#include "hycon3d.h"
#include "boxlist.h"

// compute volume of a box

#ifndef _VOLBOX_H
#define _VOLBOX_H 1

double volBox(box R);

#endif
