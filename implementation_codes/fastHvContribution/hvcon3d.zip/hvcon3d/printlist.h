#include "hycon3d.h"
#ifndef _PRINTLIST_H
#define _PRINTLIST_H 1

void printlist(point_avl list[],int n);

#endif
